<?php
// Initialize string and array
//text typed in the textarea

//array of all characters; charaters are keys and frequencies are values;


//retrieve text from the textarea


//the for loop extracts one char at a time from the string



//sort the array by keys; to sort by values, use asort()

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>

        <h2>Frequencies of Characters</h2>
        <p>Type your text into the textarea, then click on the Submit button.</p>
        <form method="post" action="index.php">
            <textarea rows="10" cols="60" name="string"><?= $string ?></textarea>
            <input type="submit" value="Submit">
        </form>


        <p><strong>Frequencies of alphanumeric characters:</strong><p>
            <?php
            
            ?>

    </body>
</html>
