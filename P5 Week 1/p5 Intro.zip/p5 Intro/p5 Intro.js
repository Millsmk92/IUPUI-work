//Matthew K. Mills
//N220
//3/19/2019
//p5 Intro
function setup() {
    createCanvas(800, 600);
    fill(255,0,0);
    strokeWeight(3);
    circle(30,30,20);
    fill(0,255,0);
    strokeWeight(2);
    square(650,500,45);
    strokeWeight(5);
    line(700,50,50,550)
    
}